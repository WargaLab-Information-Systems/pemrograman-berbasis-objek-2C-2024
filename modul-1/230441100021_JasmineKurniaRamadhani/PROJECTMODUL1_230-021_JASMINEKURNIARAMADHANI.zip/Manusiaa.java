/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package manusiaa;

/**
 *
 * @author Lenovo
 */

//public class manusiaa{
public class Manusiaa {
    // Atribut
    private String nama;
    private int umur;
    private String alamat;

    // Konstruktor
    public Manusiaa(String nama, int umur, String alamat) {
        //this untuk tidak menduplikat
        this.nama = nama;
        this.umur = umur;
        this.alamat = alamat;
    }

    // Metode berjalan
    void berjalan() {
        System.out.println(nama +umur +alamat + " sedang berjalan.");
    }

    // Metode berlari
    void berlari() {
        System.out.println(nama + umur+ alamat+ " sedang berlari.");
    }

    // Metode utama (main method)
    public static void main(String[] args) {
        // Membuat beberapa objek Manusia
        Manusiaa orang1 = new Manusiaa ("jasmine ", 18, " Situbondo");
        orang1.berjalan();
    
        Manusiaa orang2 = new Manusiaa("iklil ", 19, " Bangkalan");
        orang2.berlari();
    
        
        Manusiaa orang3 = new Manusiaa("amanda ", 19, " Gresik");
        orang3.berjalan();
    

        // Memanggil metode berjalan dan berlari untuk setiap objek
       
        
        
    }
}  
  
    



    /**
     * @param args the command line arguments
     */
 
        // TODO code application logic here
        
    
    
 
