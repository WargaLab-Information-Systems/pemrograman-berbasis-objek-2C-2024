/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rental;


public class Kendaraan {
    String jenis;
    String merek;
    String model;
    char status;
    int tahun;
    
    Kendaraan(String jenis, String merek, String model, char status, int tahun){
        this.jenis = jenis;
        this.merek = merek;
        this.model = model;
        this.status = status;
        this.tahun = tahun;
    }
    
    void display(){
        System.out.println("\nInformasi kendaraan: ");
        System.out.println("Jenis Kendaraan: "+this.jenis);
        System.out.println("Merk: "+this.merek);
        System.out.println("Model: "+this.model);
        System.out.println("Status: "+(status == 't' ? "Tersedia" : "Disewakan"));
        System.out.println("Tahun Kendaraan: "+this.tahun);
    }
    
}
