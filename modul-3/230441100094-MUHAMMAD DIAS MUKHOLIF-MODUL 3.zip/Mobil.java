/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rental;


public class Mobil extends Kendaraan {
    Mobil(String merek, String model, char status, int tahun){
        super("Mobil", merek, model, status, tahun);
    }
    
}
