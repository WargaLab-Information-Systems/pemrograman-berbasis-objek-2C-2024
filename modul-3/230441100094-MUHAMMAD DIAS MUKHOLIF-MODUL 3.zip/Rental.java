/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rental;

import java.util.Scanner;

public class Rental {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int Jumlah;
        
        System.out.println("Masukkan Jumlah Kendaraan: ");
        Jumlah = scanner.nextInt();
        
        Kendaraan[] daftarkendaraan = new Kendaraan[Jumlah];
        
        for (int j=0; j < Jumlah; j++){
            System.out.println("\nKendaraan ke-"+(j+1));
            System.out.print("Jenis Kendaraan (Mobil/Motor): ");
            String jenis = scanner.next().toLowerCase();
            System.out.print("Merek: ");
            String merek = scanner.next();
            System.out.print("Model: ");
            String model = scanner.next();
            System.out.print("Status (T/D): ");
            char status = scanner.next().charAt(0);
            System.out.print("Tahun Kendaraan: ");
            int tahun = scanner.nextInt();
            scanner.nextLine();
            
            if (jenis.equals("Mobil")){
                daftarkendaraan[j] = new Mobil(merek, model, status, tahun);
            } else if(jenis.equals("Motor")){
                daftarkendaraan[j] = new Motor(merek, model, status, tahun);
            } else {
                System.out.println("Tidak ada dalam daftar");
                return;
            }
        }
        
        System.out.println("\nDaftar kendaraan: ");
        for (Kendaraan kendaraan : daftarkendaraan){
            kendaraan.display();
            System.out.println();
        }
       
    }
    
}
