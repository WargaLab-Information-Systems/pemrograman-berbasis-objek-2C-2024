
package praktikummodul3;

/**
 *
 * @author azlif
 */

    public class Mobil extends Kendaraan {
    public Mobil(String jenisKendaraan, String merek, String model, String status, int tahunKendaraan) {
        super(jenisKendaraan, merek, model, status, tahunKendaraan);
    }
}

