
package praktikummodul3;

/**
 *
 * @author azlif
 */
public class Motor extends Kendaraan {
    public Motor(String jenisKendaraan, String merek, String model, String status, int tahunKendaraan) {
        super(jenisKendaraan, merek, model, status, tahunKendaraan);
    }
}

