/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package penyewaan_kendaraan;

/**
 *
 * @author HP
 */
public class Mobil extends Kendaraan {
    public Mobil(String merek, String model, char status, int tahun) {
        super("Mobil",merek, model, status, tahun);
    }  
}
