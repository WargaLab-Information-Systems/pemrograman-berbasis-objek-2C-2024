
package pegawai;

public class Guru extends Pegawai{
    String mataPelajaran;
    
    public Guru(String nama, String alamat, double gaji, String mataPelajaran) {
        super(nama, alamat, gaji);
        this.mataPelajaran = mataPelajaran;
    }
    public String getMataPelajaran(){
        return mataPelajaran;
    }
    public void setMataPelajaran(String mataPelajaran){
        this.mataPelajaran= mataPelajaran;
    }
    @Override
    public void kerja(){
        System.out.println("Guru sedang mengajar di kelas.");
    }
    
}
