package pegawai;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Pilih jenis pegawai:");
        System.out.println("1. Mekanik");
        System.out.println("2. Guru");
        System.out.println("3. Penyanyi");
        System.out.print("Masukkan pilihan Anda: ");

        int pilihan = scanner.nextInt();
        scanner.nextLine(); // Konsumsi enter

        String nama, alamat;
        double gaji;
        String keahlian = null, mataPelajaran = null, genreMusik = null;

        System.out.print("Masukkan nama: ");
        nama = scanner.nextLine();

        System.out.print("Masukkan alamat: ");
        alamat = scanner.nextLine();

        System.out.print("Masukkan gaji: Rp");
        gaji = scanner.nextDouble();
        scanner.nextLine(); // Konsumsi enter

        Pegawai pegawai;
        switch (pilihan) {
            case 1:
                System.out.print("Masukkan keahlian: ");
                keahlian = scanner.nextLine();
                pegawai = new Mekanik(nama, alamat, gaji, keahlian);
                break;
            case 2:
                System.out.print("Masukkan mata pelajaran: ");
                mataPelajaran = scanner.nextLine();
                pegawai = new Guru(nama, alamat, gaji, mataPelajaran);
                break;
            case 3:
                System.out.print("Masukkan genre musik: ");
                genreMusik = scanner.nextLine();
                pegawai = new Penyanyi(nama, alamat, gaji, genreMusik);
                break;
            default:
                System.out.println("Pilihan tidak valid!");
                return;
        }

        System.out.println("\nData Pegawai:");
        System.out.printf("Nama: %s\nAlamat: %s\nGaji: Rp%.2f\n", pegawai.getNama(), pegawai.getAlamat(), pegawai.getGaji());

        if (pegawai instanceof Mekanik) {
            System.out.printf("Keahlian: %s\n", ((Mekanik) pegawai).getKeahlian());
        } else if (pegawai instanceof Guru) {
            System.out.printf("Mata pelajaran: %s\n", ((Guru) pegawai).getMataPelajaran());
        } else {
            System.out.printf("Genre musik: %s\n", ((Penyanyi) pegawai).getGenreMusik());
        }

        System.out.println("\nAktivitas:");
        pegawai.kerja();
    }
}
