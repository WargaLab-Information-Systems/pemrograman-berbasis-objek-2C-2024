
package pegawai;

public class Mekanik extends Pegawai{
    String keahlian;
    
    public Mekanik(String nama, String alamat, double gaji, String keahlian) {
        super(nama, alamat, gaji);
        this.keahlian=keahlian;
    }
    public String getKeahlian(){
        return keahlian;
    }
    public void setKeahlian(String keahlian){
        this.keahlian=keahlian;
    }
    @Override
    public void kerja(){
        System.out.println("Mekanik bekerja untuk memperbaiki mesin.");
    }
}
