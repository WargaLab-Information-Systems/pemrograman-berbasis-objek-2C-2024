
package pegawai;

public class Penyanyi extends Pegawai {
    String genreMusik;
    
    public Penyanyi(String nama, String alamat, double gaji, String genreMusik) {
        super(nama, alamat, gaji);
        this.genreMusik = genreMusik;
    }
    public String getGenreMusik(){
        return genreMusik;
    }
    public void setGenreMusik(String genreMusik){
        this.genreMusik = genreMusik;
    }
    @Override
    public void kerja(){
        System.out.println("Penyanyi yang bernyanyi di atas panggung.");
    }
}
