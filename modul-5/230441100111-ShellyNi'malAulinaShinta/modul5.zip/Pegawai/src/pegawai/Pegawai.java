
package pegawai;

public class Pegawai {
    String nama;
    String alamat;
    double gaji;
    
    Pegawai(String nama, String alamat, double gaji){
        this.nama = nama;
        this.alamat = alamat;
        this.gaji = gaji;
    }
    public String getNama(){
        return nama;
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    public String getAlamat(){
        return alamat;
    }
    public void setAlamat(String Alamat){
        this.alamat=alamat;
    }
    public double getGaji(){
        return gaji;
    }
    public void setGaji(double gaji){
        this.gaji = gaji;
    }
    public void kerja(){
        System.out.println("Pegawai yang bekerja. ");
    }
    
}
