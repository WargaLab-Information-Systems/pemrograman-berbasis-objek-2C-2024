
package satuan;


public class waktu extends Satuan {
    public waktu(double nilai, String satuanAsal){
        super(nilai,satuanAsal);
    }


    @Override
    public double KonversiKe(String satuanTujuan) {
        switch (satuanTujuan) {
            case "Detik":
                if (getSatuanAsal().equals("menit")) {
                    return getNilai() * 60;
                } else if (getSatuanAsal().equals("jam")) {
                    return getNilai() * 3600;
                } else {
                    return getNilai();
                }
            case "Menit":
                if (getSatuanAsal().equals("detik")) {
                    return getNilai() / 60;
                } else if (getSatuanAsal().equals("jam")) {
                    return getNilai() * 60;
                } else {
                    return getNilai();
                }
            case "Jam":
                if (getSatuanAsal().equals("detik")) {
                    return getNilai() / 3600;
                } else if (getSatuanAsal().equals("menit")) {
                    return getNilai() / 60;
                } else {
                    return getNilai();
                }
            default:
                return getNilai();
         }    

        
    }
    
    
}
