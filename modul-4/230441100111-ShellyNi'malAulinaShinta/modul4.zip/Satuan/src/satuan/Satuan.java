package satuan;

public abstract class Satuan{
    double nilai;
    String satuanAsal;
    
    public Satuan(double nilai, String satuanAsal){
        this.nilai = nilai;
        this.satuanAsal= satuanAsal;
    }
    
    public abstract double KonversiKe(String satuanTujuan);
    public double getNilai(){
        return nilai;
    }
    
    public String getSatuanAsal(){
        return satuanAsal;
    }

}