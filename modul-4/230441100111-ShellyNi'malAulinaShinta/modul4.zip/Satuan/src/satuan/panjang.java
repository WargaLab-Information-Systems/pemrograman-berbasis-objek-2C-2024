
package satuan;

//kelas turunan pada panjang
public class panjang extends Satuan{
    
    public panjang(double nilai, String satuanAsal){
        super(nilai, satuanAsal);
    }

    @Override
    public double KonversiKe(String satuanTujuan) {
        switch (satuanTujuan) {
            case "Meter":
                if (getSatuanAsal().equals("kilometer")) {
                    return getNilai() * 1000;
                } else if (getSatuanAsal().equals("centimeter")) {
                    return getNilai() / 100;
                } else {
                    return getNilai();
                }
            case "Kilometer":
                if (getSatuanAsal().equals("meter")) {
                    return getNilai() / 1000;
                } else if (getSatuanAsal().equals("centimeter")) {
                    return getNilai() / 100000;
                } else {
                    return getNilai();
                }
            case "Centimeter":
                if (getSatuanAsal().equals("meter")) {
                    return getNilai() * 100;
                } else if (getSatuanAsal().equals("kilometer")) {
                    return getNilai() * 100000;
                } else {
                    return getNilai();
                }
            default:
                return getNilai();
        }    
       }
}
