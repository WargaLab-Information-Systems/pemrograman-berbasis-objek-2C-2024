package satuan;

// Kelas turunan pada suhu
public class suhu extends Satuan {
    public suhu(double nilai, String satuanAsal) {
        super(nilai, satuanAsal);
    }

    @Override
    public double KonversiKe(String satuanTujuan) {
        switch(satuanTujuan){
            case"Celcius":
               if (getSatuanAsal().equals("fahrenheit")) {
                    return (getNilai() - 32) * 5 / 9;
                } else if (getSatuanAsal().equals("kelvin")) {
                    return getNilai() - 273.15;
                } else {
                    return getNilai();
                }
            case "Fahrenheit":
                if (getSatuanAsal().equals("celcius")) {
                    return (getNilai() * 9 / 5) + 32;
                } else if (getSatuanAsal().equals("kelvin")) {
                    return (getNilai() - 273.15) * 9 / 5 + 32;
                } else {
                    return getNilai();
                }
            case "Kelvin":
                if (getSatuanAsal().equals("celcius")) {
                    return getNilai() + 273.15;
                } else if (getSatuanAsal().equals("fahrenheit")) {
                    return (getNilai() - 32) * 5 / 9 + 273.15;
                } else {
                    return getNilai();
                }
            default:
                return getNilai();

        }
          
    }
        }

