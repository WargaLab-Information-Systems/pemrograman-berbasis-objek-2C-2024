/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package satuan;

/**
 *
 * @author Shely
 */
public class Berat extends Satuan {
    public Berat(double nilai, String satuanAsal){
        super(nilai,satuanAsal);
    }

    @Override
    public double KonversiKe(String satuanTujuan) {
        switch (satuanTujuan) {
            case "Kilogram":
                if (getSatuanAsal().equals("gram")) {
                    return getNilai() / 1000;
                } else if (getSatuanAsal().equals("ton")) {
                    return getNilai() * 1000;
                } else {
                    return getNilai();
                }
            case "Gram":
                if (getSatuanAsal().equals("kilogram")) {
                    return getNilai() * 1000;
                } else if (getSatuanAsal().equals("ton")) {
                    return getNilai() * 1000000;
                } else {
                    return getNilai();
                }
            case "Ton":
                if (getSatuanAsal().equals("kilogram")) {
                    return getNilai() / 1000;
                } else if (getSatuanAsal().equals("gram")) {
                    return getNilai() / 1000000;
                } else {
                    return getNilai();
                }
            default:
                return getNilai();
        }    
        }
}
