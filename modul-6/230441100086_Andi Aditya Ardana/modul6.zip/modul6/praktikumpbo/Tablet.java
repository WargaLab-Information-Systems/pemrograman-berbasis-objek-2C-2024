// Tablet.java
package modul6.praktikumpbo;

public class Tablet extends Gadget {
    Tablet(String merk, String model) {
        super(merk, model);
    }
}
