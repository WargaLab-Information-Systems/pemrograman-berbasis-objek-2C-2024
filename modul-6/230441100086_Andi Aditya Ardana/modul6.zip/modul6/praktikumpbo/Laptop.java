// Laptop.java
package modul6.praktikumpbo;

public class Laptop extends Gadget {
    Laptop(String merk, String model) {
        super(merk, model);
    }
}
