// Smartphone.java
package modul6.praktikumpbo;

public class Smartphone extends Gadget {
    Smartphone(String merk, String model) {
        super(merk, model);
    }
}
