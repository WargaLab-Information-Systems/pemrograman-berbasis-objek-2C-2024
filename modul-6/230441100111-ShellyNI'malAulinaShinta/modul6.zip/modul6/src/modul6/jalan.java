package modul6;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class jalan {

    public static void main(String[] args) {
        // Input data gadget dari pengguna
        Scanner scanner = new Scanner(System.in);

        System.out.println("**Program Data Gadget**");

        boolean lanjutInput = true;
        while (lanjutInput) {
            // Input jumlah gadget baru
            System.out.print("Berapa banyak gadget yang ingin Anda masukkan? ");
            int jumlahGadget = scanner.nextInt();

            List<Gadget> daftarGadget = new ArrayList<>();

            // Looping untuk input data setiap gadget
            for (int i = 0; i < jumlahGadget; i++) {
                System.out.println("\n**Gadget ke-" + (i + 1) + "**");

                System.out.print("Masukkan merk gadget: ");
                String merk = scanner.next();

                System.out.print("Masukkan model gadget: ");
                String model = scanner.next();

                System.out.print("Jenis gadget (smartphone, tablet, laptop): ");
                String jenisGadget = scanner.next().toLowerCase();

                Gadget gadget;
                switch (jenisGadget) {
                    case "smartphone":
                        gadget = new smartphone(merk, model);
                        break;
                    case "tablet":
                        gadget = new Tablet(merk, model);
                        break;
                    case "laptop":
                        gadget = new laptop(merk, model);
                        break;
                    default:
                        System.out.println("Jenis gadget tidak valid. Lewati gadget ini.");
                        continue;
                }

                // Input data spesifikasi tambahan untuk laptop
                if (gadget instanceof laptop) {
                    System.out.print("Masukkan sistem operasi: ");
                    ((laptop) gadget).setSistemOperasi(scanner.next());

                    System.out.print("Masukkan kapasitas RAM: ");
                    ((laptop) gadget).setRam(scanner.next());

                    System.out.print("Masukkan kapasitas penyimpanan: ");
                    ((laptop) gadget).setPenyimpanan(scanner.next());

                    System.out.print("Masukkan ukuran layar: ");
                    ((laptop) gadget).setLayar(scanner.next());

                    System.out.print("Masukkan jenis prosesor: ");
                    ((laptop) gadget).setProsesor(scanner.next());

                    System.out.print("Masukkan durasi baterai: ");
                    ((laptop) gadget).setBaterai(scanner.next());
                }

                daftarGadget.add(gadget);
            }

            // Tampilkan data gadget
            System.out.println("\n**Daftar Gadget**");
            for (Gadget gadget : daftarGadget) {
                gadget.tampilkanSpesifikasi();
                System.out.println();
            }

            // Tanyakan apakah ingin input data baru
            System.out.print("Apakah Anda ingin input data gadget baru? (y/n): ");
            String inputLanjut = scanner.next().toLowerCase();
            lanjutInput = inputLanjut.equals("y");
        }

        System.out.println("Terima kasih telah menggunakan program ini!");
        scanner.close();
    }
}
