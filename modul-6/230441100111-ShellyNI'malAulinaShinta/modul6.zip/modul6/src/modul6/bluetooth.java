
package modul6;


public interface bluetooth {
    void kirimFile();

    void terimaFile();

    void koneksiPerangkat();
}

