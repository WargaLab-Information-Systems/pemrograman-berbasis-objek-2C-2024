package modul6;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numSmartphones, numTablets, numLaptops;
        do {
            System.out.print("Masukkan jumlah Smartphone yang diinginkan (minimal 1): ");
            numSmartphones = scanner.nextInt();
        } while (numSmartphones < 1);

        do {
            System.out.print("Masukkan jumlah Tablet yang diinginkan (minimal 1): ");
            numTablets = scanner.nextInt();
        } while (numTablets < 1);

        do {
            System.out.print("Masukkan jumlah Laptop yang diinginkan (minimal 1): ");
            numLaptops = scanner.nextInt();
        } while (numLaptops < 1);

      
        int totalGadgets = numSmartphones + numTablets + numLaptops;

        
        Gadget[] gadgets = new Gadget[totalGadgets];

        
        int gadgetIndex = 0; 
        
        for (int i = 0; i < numSmartphones; i++) {
            System.out.println("\n=================== INPUT JENIS GADGET (Smartphone " + (i + 1) + ") ===================");
            System.out.print("Masukkan Merek Smartphone: ");
            String merekSmartphone = scanner.next();
            System.out.print("Masukkan Model Smartphone: ");
            String modelSmartphone = scanner.next();
            gadgets[gadgetIndex++] = new smartphone(merekSmartphone, modelSmartphone);
        } 
        
        for (int i = 0; i < numTablets; i++) {
            System.out.println("\n=================== INPUT JENIS GADGET (Tablet " + (i + 1) + ") ===================");
            System.out.print("Masukkan Merek Tablet: ");
            String merekTablet = scanner.next();
            System.out.print("Masukkan Model Tablet: ");
            String modelTablet = scanner.next();
            gadgets[gadgetIndex++] = new Tablet(merekTablet, modelTablet);
        }

        for (int i = 0; i < numLaptops; i++) {
            System.out.println("\n=================== INPUT JENIS GADGET (Laptop " + (i + 1) + ") ===================");
            System.out.print("Masukkan Merek Laptop: ");
            String merekLaptop = scanner.next();
            System.out.print("Masukkan Model Laptop: ");
            String modelLaptop = scanner.next();
            gadgets[gadgetIndex++] = new laptop(merekLaptop, modelLaptop);
            
            System.out.print("Masukkan Sistem Operasi: ");
            ((laptop) gadgets[gadgetIndex - 1]).setSistemOperasi(scanner.next());
            System.out.print("Masukkan RAM (misal: 8GB): ");
            ((laptop) gadgets[gadgetIndex - 1]).setRam(scanner.next());
            System.out.print("Masukkan Penyimpanan (misal: 512GB): ");
            ((laptop) gadgets[gadgetIndex - 1]).setPenyimpanan(scanner.next());
            System.out.print("Masukkan Layar (misal: 15.6 inci): ");
            ((laptop) gadgets[gadgetIndex - 1]).setLayar(scanner.next());
            System.out.print("Masukkan Prosesor (misal: Intel Core i7): ");
            ((laptop) gadgets[gadgetIndex - 1]).setProsesor(scanner.next());
            System.out.print("Masukkan Baterai (misal: 4000mAh): ");
            ((laptop) gadgets[gadgetIndex - 1]).setBaterai(scanner.next());
        }
        
        System.out.println("\n=================== DATA GADGET ===================");
        for (int i = 0; i < gadgets.length; i++) {
            System.out.println("\n=================== DATA GADGET KE " + (i + 1) + " ===================");
            gadgets[i].tampilkanSpesifikasi();
    }
    }
}