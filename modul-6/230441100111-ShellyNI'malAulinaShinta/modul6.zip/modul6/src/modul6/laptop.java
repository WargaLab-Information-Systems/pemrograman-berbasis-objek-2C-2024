package modul6;

public class laptop extends Gadget implements kamera, bluetooth, Wifi, gps {

    private String sistemOperasi;
    private String ram;
    private String penyimpanan;
    private String layar;
    private String prosesor;
    private String baterai;

    public laptop(String merk, String model) {
        super(merk, model);
    }

    public void setSistemOperasi(String sistemOperasi) {
        this.sistemOperasi = sistemOperasi;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public void setPenyimpanan(String penyimpanan) {
        this.penyimpanan = penyimpanan;
    }

    public void setLayar(String layar) {
        this.layar = layar;
    }

    public void setProsesor(String prosesor) {
        this.prosesor = prosesor;
    }

    public void setBaterai(String baterai) {
        this.baterai = baterai;
    }

    public String getSistemOperasi() {
        return sistemOperasi;
    }

    public String getRam() {
        return ram;
    }

    public String getPenyimpanan() {
        return penyimpanan;
    }

    public String getLayar() {
        return layar;
    }

    public String getProsesor() {
        return prosesor;
    }

    public String getBaterai() {
        return baterai;
    }

    @Override
    public void tampilkanSpesifikasi() {
        System.out.println("Spesifikasi Laptop:");
        System.out.println("Merk: " + getMerk());
        System.out.println("Model: " + getModel());
        System.out.println("Fitur:");
        System.out.println("- Sistem Operasi: " + getSistemOperasi());
        System.out.println("- RAM: " + getRam());
        System.out.println("- Penyimpanan: " + getPenyimpanan());
        System.out.println("- Layar: " + getLayar());
        System.out.println("- Prosesor: " + getProsesor());
        System.out.println("- Baterai: " + getBaterai());
        ambilFoto();
        rekamVideo();
        kirimFile();
        terimaFile();
        koneksiPerangkat();
        cariJaringan();
        hubungkanJaringan();
        lupakanJaringan();
        ambilKoordinat();
        System.out.println();
    }

    @Override
    public void ambilFoto() {
        System.out.println("Laptop bisa ambil foto");
    }

    @Override
    public void rekamVideo() {
        System.out.println("Laptop bisa ngerekam video");
    }

    @Override
    public void kirimFile() {
        System.out.println("Laptop bisa kirim file");
        }

    @Override
    public void terimaFile() {
        System.out.println("Laptop bisa terima file");
    }

    @Override
    public void koneksiPerangkat() {
        System.out.println("Laptop bisa koneksi perangkat");
        }

    @Override
    public void cariJaringan() {
        System.out.println("Laptop bisa mencari jarigan");
    }

    @Override
    public void hubungkanJaringan() {
        System.out.println("laptop bisa menghubungkan jaringan");
        }

    @Override
    public void lupakanJaringan() {
        System.out.println("laptop bisa melupakan jaringan");
        }

    @Override
    public void ambilKoordinat() {
        System.out.println("laptop bisa ambil koordinat");
       }
}
