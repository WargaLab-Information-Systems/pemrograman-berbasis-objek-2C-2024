
package modul6;

public interface Wifi {
    void cariJaringan();

    void hubungkanJaringan();

    void lupakanJaringan();
}


