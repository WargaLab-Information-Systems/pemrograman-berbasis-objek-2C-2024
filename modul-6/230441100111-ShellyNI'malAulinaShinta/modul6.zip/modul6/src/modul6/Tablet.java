
package modul6;


public class Tablet extends Gadget implements kamera, Wifi, bluetooth, gps{

    public Tablet(String merk, String model) {
        super(merk, model);
    }

    @Override
    public void tampilkanSpesifikasi() {
        System.out.println("Spesifikasi Tablet:");
        System.out.println("Merk: " + getMerk());
        System.out.println("Model: " + getModel());
        ambilFoto();
        rekamVideo();
        kirimFile();
        terimaFile();
        koneksiPerangkat();
        cariJaringan();
        hubungkanJaringan();
        lupakanJaringan();
        ambilKoordinat();
    }

    @Override
    public void cariJaringan() {
        System.out.println("Cari jaringan Wifi tablet.");
    }

    @Override
    public void hubungkanJaringan() {
        System.out.println("Hubungkan jaringan Wifi tablet.");
    }

    @Override
    public void lupakanJaringan() {
        System.out.println("Lupakan jaringan Wifi tablet.");
    }

    @Override
    public void ambilKoordinat() {
        System.out.println("Ambil koordinat GPS tablet.");
    }

    @Override
    public void rekamVideo() {
        System.out.println("Rekam video dengan kamera tablet");
    }

    @Override
    public void kirimFile() {
        System.out.println("Kirim file via bluetooth tablet.");
    }

    @Override
    public void terimaFile() {
        System.out.println("Terima file via bluetooth tablet.");
    }

    @Override
    public void koneksiPerangkat() {
        System.out.println("Terima koneksi perangkat bluetooth tablet.");
    }

    @Override
    public void ambilFoto() {
        System.out.println("Ambil foto dengan kamera tablet");
    }
    
}
