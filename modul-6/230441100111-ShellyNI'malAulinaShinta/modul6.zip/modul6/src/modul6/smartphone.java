
package modul6;

public class smartphone extends Gadget implements kamera, bluetooth, Wifi, gps {

    public smartphone(String merk, String model) {
        super(merk, model);
    }

    @Override
    public void tampilkanSpesifikasi() {
        System.out.println("Spesifikasi Smartphone:");
        System.out.println("Merk: " + getMerk());
        System.out.println("Model: " + getModel());
        ambilFoto();
        rekamVideo();
        kirimFile();
        terimaFile();
        koneksiPerangkat();
        cariJaringan();
        hubungkanJaringan();
        lupakanJaringan();
        ambilKoordinat();
    }


    @Override
    public void rekamVideo() {
        System.out.println("Rekam video dengan kamera smartphone");
    }

    @Override
    public void kirimFile() {
        System.out.println("Kirim file via bluetooth smartphone.");
    }

    @Override
    public void terimaFile() {
        System.out.println("Terima file via bluetooth smartphone.");
    }

    @Override
    public void koneksiPerangkat() {
         System.out.println("Terima koneksi perangkat bluetooth smartphone.");
    }

    @Override
    public void cariJaringan() {
        System.out.println("Cari jaringan WIFI smartphone.");
    }

    @Override
    public void hubungkanJaringan() {
        System.out.println("Hubungkan jaringan WIFI smartphone");
    }

    @Override
    public void lupakanJaringan() {
        System.out.println("Lupakan jaringan WIFI smartphone.");
    }

    @Override
    public void ambilKoordinat() {
        System.out.println("Ambil koordinat GPS smartphone.");
    }

    @Override
    public void ambilFoto() {
        System.out.println("Ambil foto dengan kamera Smartphone");
    }
    
}
