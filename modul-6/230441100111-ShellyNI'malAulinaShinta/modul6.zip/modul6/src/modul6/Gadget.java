
package modul6;


public abstract class Gadget {
    private String merk;
    private String model;

    public Gadget(String merk, String model) {
        this.merk = merk;
        this.model = model;
    }

    public String getMerk() {
        return merk;
    }

    public String getModel() {
        return model;
    }

    public abstract void tampilkanSpesifikasi();
}
