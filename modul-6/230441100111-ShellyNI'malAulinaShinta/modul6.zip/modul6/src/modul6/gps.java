
package modul6;

public interface gps {
    void ambilKoordinat();
}

