
package modul6;

public interface kamera {
    void ambilFoto();

    void rekamVideo();
}
