
package gadget;

interface Kamera {
    void ambilFoto();
    void rekamVideo();
}

interface Bluetooth {
    void kirimFile();
    void terimaFile();
    void koneksiPerangkat();
}

interface Wifi {
    void cariJaringan();
    void hubungkanJaringan();
    void lupakanJaringan();
}

interface GPS {
    void ambilKoordinat();
}

public abstract class Gadget implements Kamera, Bluetooth, Wifi, GPS {
    String Merk, Model;

    public Gadget(String Merk, String Model) {
        this.Merk = Merk;
        this.Model = Model;
    }

    public abstract void Display();
}
