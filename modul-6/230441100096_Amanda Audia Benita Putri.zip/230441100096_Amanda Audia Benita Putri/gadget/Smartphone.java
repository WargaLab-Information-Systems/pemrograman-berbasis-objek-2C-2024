package gadget;

public class Smartphone extends Gadget implements Kamera, Bluetooth, Wifi, GPS{
    Smartphone(String Merk, String Model) {
        super(Merk, Model);
    }
    //kamera
    @Override
    public void ambilFoto(){
       System.out.println("smartphone " + Merk + " dengan model " + Model + " memiliki fitur kamera dengan hasil Foto yang jernih ");
    }
    @Override
    public void rekamVideo(){
        System.out.println("smartphone " + Merk + " dengan model " + Model + " dapat Merekam Video dengan kualitas bagus");
    }
    //bluetooth
    @Override
    public void kirimFile(){
        System.out.println("smartphone " + Merk + " dengan model " + Model + " dapat Mengirim File");
    }
    @Override
    public void terimaFile(){
        System.out.println("smartphone " + Merk + " dengan model " + Model + " dapat Menerima File");
    }
    @Override
    public void koneksiPerangkat(){
        System.out.println("smartphone " + Merk + " dengan model " + Model + " Mengkoneksikan Perangkat");
    }
    //wifi
    @Override
    public void cariJaringan(){
        System.out.println("smartphone " + Merk + " dengan model "  + Model + " Mencari Jaringan");
    }
    @Override
    public void hubungkanJaringan(){
        System.out.println("smartphone " + Merk + " dengan model "  + Model + " Menghubungkan Jaringan ke perangkat lain");
    }
    @Override
    public void lupakanJaringan(){
        System.out.println("smartphone " + Merk + " dengan model "  + Model + " memutus Jaringan");
    }
    //gps
    @Override
    public void ambilKoordinat(){
        System.out.println("smartphone " + Merk + " dengan model "  + Model + " Mengambil Koordinat yang lumayan akurat");
    }
    @Override
    public void Display() {
        System.out.println("\nElektronik Smartphone");
        System.out.println("Merk    : " + Merk);
        System.out.println("Model   : " + Model);
    }

    
   
}

