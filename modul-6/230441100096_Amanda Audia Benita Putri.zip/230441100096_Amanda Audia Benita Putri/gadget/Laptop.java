package gadget;

public class Laptop extends Gadget implements Kamera, Bluetooth, Wifi, GPS {
    public Laptop(String Merk, String Model) {
        super(Merk, Model);
        
    }
    @Override
    public void Display() {
        System.out.println("\nElektronik laptop");
        System.out.println("Merk    : " + Merk);
        System.out.println("Model   : " + Model);
    }
    //kamera
    @Override
    public void ambilFoto(){
        System.out.println("laptop " + Merk + " dengan model " + Model + " memiliki fitur kamera yang jelas");
    }
    @Override
    public void rekamVideo(){
        System.out.println("laptop " + Merk + " dengan model " + Model + " mampu Merekam Video");
    }
    //bluetooth
    @Override
    public void kirimFile(){
        System.out.println("laptop " + Merk + " dengan model " + Model + " bisa Mengirim File dalam jumlah yang banyak");
    }
    @Override
    public void terimaFile(){
        System.out.println("laptop " + Merk + " dengan model " + Model + " bisa Menerima File dalam jumlah yang banyak");
    }
    @Override
    public void koneksiPerangkat(){
        System.out.println("laptop " + Merk + " dengan model" + Model + " bisa Mengkoneksikan denganPerangkat apa saja");
    }
    //wifi
    @Override
    public void cariJaringan(){
        System.out.println("laptop " + Merk + " dengan model " + Model + " bisa Mencari Jaringan dengan lancar");
    }
    @Override
    public void hubungkanJaringan(){
        System.out.println("laptop " + Merk + " dengan model " + Model + " bisa Menghubungkan Jaringan ke bebarapa perangkat");
    }
    @Override
    public void lupakanJaringan(){
        System.out.println("laptop " + Merk + " dengan mode l" + Model + " bisa Melupakan Jaringan");
    }
    //gps
    @Override
    public void ambilKoordinat(){
        System.out.println("laptop " + Merk + " dengan model " + Model + " Mengambil Koordinat yang akurat");
    }
}

