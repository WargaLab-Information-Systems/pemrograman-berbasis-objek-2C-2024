
package gadget;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean ulang = true;      
        while (ulang) {
            System.out.println("\nPilih Jenis barang elektronik yang ingin dimasukkan");
            System.out.println("1. Smartphone");
            System.out.println("2. Laptop");
            System.out.println("3. Tablet");
            System.out.print("Masukkan pilihan anda: ");
            int pilihan = input.nextInt();
            input.nextLine(); 
            
            if (pilihan < 1 || pilihan > 3){
                System.out.println("\n Masukkan jenis barang elektronik yang benar");
                        continue;
            }
            
            System.out.print("Masukkan Merk ke-1  : ");
            String merk = input.nextLine();
            System.out.print("Masukkan Merk ke-2  : ");
            String merk2 = input.nextLine();
            System.out.print("Masukkan Merk ke-3  : ");
            String merk3 = input.nextLine();
            System.out.print("Masukkan Model ke-1 : ");
            String model = input.nextLine();
            System.out.print("Masukkan Model ke-2 : ");
            String model2 = input.nextLine();
            System.out.print("Masukkan Model ke-3 : ");
            String model3 = input.nextLine();
            Gadget Gadget = null;
            if (pilihan == 1) {
                while (true) {
                    System.out.println("\nPilihan Menu Informasi Spesifikasi");
                    System.out.println("1. Kamera");
                    System.out.println("2. Gps");
                    System.out.println("3. Bluetooth");
                    System.out.println("4. Wifi");
                    System.out.println("5. Kembali ke Menu Utama");
                    System.out.print("Masukkan Pilihan Spesifikasi Yang Ingin di Cek: ");
                    int pilihanSpesifikasi = input.nextInt();
                    input.nextLine();
                    if (pilihanSpesifikasi == 1) {
                        Gadget = new Smartphone(merk, model);
                        Gadget.Display();
                        Gadget.ambilFoto();
                        Gadget.rekamVideo();
                        Smartphone Gadget2 = new Smartphone( merk2, model2);
                        Gadget2.Display();
                        Gadget2.ambilFoto();
                        Gadget2.rekamVideo();
                        Smartphone Gadget3 = new Smartphone( merk3, model3);
                        Gadget3.Display();
                        Gadget3.ambilFoto();
                        Gadget2.rekamVideo();
                    } else if (pilihanSpesifikasi == 2) {
                        Gadget = new Smartphone(merk, model);
                        Gadget.Display();
                        Gadget.ambilKoordinat();
                        Smartphone Gadget2 = new Smartphone(merk2, model2);
                        Gadget2.Display();
                        Gadget2.ambilKoordinat();
                        Smartphone Gadget3 = new Smartphone(merk3, model3);
                        Gadget3.Display();
                        Gadget3.ambilKoordinat();
                    } else if (pilihanSpesifikasi == 3) {
                        Gadget = new Smartphone(merk, model);
                        Gadget.Display();
                        Gadget.kirimFile();
                        Gadget.terimaFile();
                        Gadget.koneksiPerangkat();
                        Smartphone Gadget2 = new Smartphone( merk2, model2);
                        Gadget2.Display();
                        Gadget2.kirimFile();
                        Gadget2.terimaFile();
                        Gadget2.koneksiPerangkat();
                        Smartphone Gadget3 = new Smartphone( merk3, model3);
                        Gadget3.Display();
                        Gadget3.kirimFile();
                        Gadget3.terimaFile();
                        Gadget3.koneksiPerangkat();
                    } else if (pilihanSpesifikasi == 4) {
                        Gadget = new Smartphone(merk, model);
                        Gadget.Display();
                        Gadget.cariJaringan();
                        Gadget.hubungkanJaringan();
                        Gadget.lupakanJaringan();
                        Smartphone Gadget2 = new Smartphone( merk2, model2);
                        Gadget2.Display();
                        Gadget2.cariJaringan();
                        Gadget2.hubungkanJaringan();
                        Gadget2.lupakanJaringan();
                        Smartphone Gadget3 = new Smartphone( merk3, model3);
                        Gadget3.Display();
                        Gadget3.cariJaringan();
                        Gadget3.hubungkanJaringan();
                        Gadget3.lupakanJaringan();
                    } else if (pilihanSpesifikasi == 5) {
                        break; // Kembali ke Menu Utama
                    } else {
                        System.out.println("Pilihan spesifikasi tidak valid.");
                    }
                }
            } else if (pilihan == 2) {
                while (true) {
                    System.out.println("\nMenu Informasi Spesifikasi");
                    System.out.println("1. Kamera");
                    System.out.println("2. Gps");
                    System.out.println("3. Bluetooth");
                    System.out.println("4. Wifi");
                    System.out.println("5. Kembali ke Menu Utama");
                    System.out.print("Masukkan Pilihan Spesifikasi Yang Ingin Anda Cek : ");
                    int pilihanSpesifikasi = input.nextInt();
                    input.nextLine();
                    if (pilihanSpesifikasi == 1) {
                        Gadget = new Laptop(merk, model);
                        Gadget.Display();
                        Gadget.ambilFoto();
                        Gadget.rekamVideo(); 
                        Gadget.rekamVideo();
                        Laptop Gadget2 = new Laptop(merk2, model2);
                        Gadget2.Display();
                        Gadget2.ambilFoto();
                        Gadget2.rekamVideo(); 
                        Gadget2.rekamVideo();
                        Laptop Gadget3 = new Laptop(merk3, model3);
                        Gadget3.Display();
                        Gadget3.ambilFoto();
                        Gadget3.rekamVideo(); 
                        Gadget3.rekamVideo();
                    } else if (pilihanSpesifikasi == 2) {
                        Gadget = new Laptop(merk, model);
                        Gadget.Display();
                        Gadget.ambilKoordinat();
                        Laptop Gadget2 = new Laptop(merk2, model2);
                        Gadget2.Display();
                        Gadget.ambilKoordinat();
                        Laptop Gadget3 = new Laptop(merk3, model3);
                        Gadget3.Display();
                        Gadget.ambilKoordinat();
                    } else if (pilihanSpesifikasi == 3) {
                        Gadget = new Laptop(merk, model);
                        Gadget.Display();
                        Gadget.kirimFile();
                        Gadget.terimaFile();
                        Gadget.koneksiPerangkat();
                        Laptop Gadget2 = new Laptop(merk2, model2);
                        Gadget2.Display();
                        Gadget2.kirimFile();
                        Gadget2.terimaFile();
                        Gadget2.koneksiPerangkat();
                        Laptop Gadget3 = new Laptop(merk3, model3);
                        Gadget3.Display();
                        Gadget3.kirimFile();
                        Gadget3.terimaFile();
                        Gadget3.koneksiPerangkat();
                    } else if (pilihanSpesifikasi == 4) {
                        Gadget = new Laptop(merk, model);
                        Gadget.Display();
                        Gadget.cariJaringan();
                        Gadget.hubungkanJaringan();
                        Gadget.lupakanJaringan();
                        Laptop Gadget2 = new Laptop(merk2, model2);
                        Gadget2.Display();
                        Gadget2.cariJaringan();
                        Gadget2.hubungkanJaringan();
                        Gadget2.lupakanJaringan();
                        Laptop Gadget3 = new Laptop(merk3, model3);
                        Gadget3.Display();
                        Gadget3.cariJaringan();
                        Gadget3.hubungkanJaringan();
                        Gadget3.lupakanJaringan();
                    } else if (pilihanSpesifikasi == 5) {
                        break; // Kembali ke Menu Utama
                    } else {
                        System.out.println("Pilihan spesifikasi yang dimasukkan tidak valid.");
                    }
                }
            } else if (pilihan == 3) {
                while (true) {
                    System.out.println("\nMenu Informasi Spesifikasi");
                    System.out.println("1. Kamera");
                    System.out.println("2. Gps");
                    System.out.println("3. Bluetooth");
                    System.out.println("4. Wifi");
                    System.out.println("5. Kembali ke Menu Utama");
                    System.out.print("Masukkan Pilihan Spesifikasi Yang Ingin Anda Cek : ");
                    int pilihanSpesifikasi = input.nextInt();
                    input.nextLine();
                    if (pilihanSpesifikasi == 1) {
                        Gadget = new Tablet(merk, model);
                        Gadget.Display();
                        Gadget.ambilFoto();
                        Gadget.rekamVideo();
                        Tablet Gadget2 = new Tablet(merk2, model2);
                        Gadget2.Display();
                        Gadget2.ambilFoto();
                        Gadget2.rekamVideo();
                        Tablet Gadget3 = new Tablet(merk3, model3);
                        Gadget3.Display();
                        Gadget3.ambilFoto();
                        Gadget3.rekamVideo();
                    } else if (pilihanSpesifikasi == 2) {
                        Gadget = new Tablet(merk, model);
                        Gadget.Display();
                        Gadget.ambilKoordinat();
                        Tablet Gadget2 = new Tablet(merk2, model2);
                        Gadget2.Display();
                        Gadget2.ambilKoordinat();
                        Tablet Gadget3 = new Tablet(merk3, model3);
                        Gadget3.Display();
                        Gadget3.ambilKoordinat();
                    } else if (pilihanSpesifikasi == 3) {
                        Gadget = new Tablet(merk, model);
                        Gadget.Display();
                        Gadget.kirimFile();
                        Gadget.terimaFile();
                        Gadget.koneksiPerangkat();
                        Tablet Gadget2 = new Tablet(merk2, model2);
                        Gadget2.Display();
                        Gadget2.kirimFile();
                        Gadget2.terimaFile();
                        Gadget2.koneksiPerangkat();
                        Tablet Gadget3 = new Tablet(merk3, model3);
                        Gadget3.Display();
                        Gadget3.kirimFile();
                        Gadget3.terimaFile();
                        Gadget3.koneksiPerangkat();
                    } else if (pilihanSpesifikasi == 4) {
                        Gadget = new Tablet(merk, model);
                        Gadget.Display();
                        Gadget.cariJaringan();
                        Gadget.hubungkanJaringan();
                        Gadget.lupakanJaringan();
                        Tablet Gadget2 = new Tablet(merk2, model2);
                        Gadget2.Display();
                        Gadget2.cariJaringan();
                        Gadget2.hubungkanJaringan();
                        Gadget2.lupakanJaringan();
                        Tablet Gadget3 = new Tablet(merk3, model3);
                        Gadget3.Display();
                        Gadget3.cariJaringan();
                        Gadget3.hubungkanJaringan();
                        Gadget3.lupakanJaringan();
                    } else if (pilihanSpesifikasi == 5) {
                        break; // Kembali ke Menu Utama
                    } else {
                        System.out.println("Pilihan spesifikasi yang dimasukkan tidak valid.");
                    }
                }
            } else {
                System.out.println("\ninputan anda salah!");
            }
            System.out.print("\nApakah Anda ingin melanjutkan program? (y / n): ");
            String tanya = input.nextLine();
            if (tanya.equalsIgnoreCase("n")) {
                System.out.println("Program yang anda jalankan Selesai");
                ulang = false;
            } else if (tanya.equalsIgnoreCase("y")) {
                System.out.println("Inputan anda tidak valid!");
            }
        }
    }
}