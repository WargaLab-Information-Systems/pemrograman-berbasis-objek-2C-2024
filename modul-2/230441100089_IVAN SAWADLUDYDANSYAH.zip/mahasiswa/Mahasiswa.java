/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mahasiswa;

public class Mahasiswa {
    String nama;
    int nim;
    String jurusan;
    String alamat;
    String prodi ;
   

    Mahasiswa(String nama, int NIM, String jurusan, String alamat, String prodi) {
        this.nama = nama;
        nim = NIM;
        this.jurusan = jurusan;
        this.alamat = alamat;
        this.prodi = prodi;
 
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public void setNim(int NIM) {
        nim = NIM;
    }

    int getNim() {
        return nim;
    }

    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }

    public String getJurusan() {
        return jurusan;
    }
    
    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getAlamat() {
        return alamat;
    }

    
    public void SetProdi(String prodi) {
        this.prodi = prodi;
    }
    
    public String getProdi() {
        return prodi;
    }

    public static void main(String[] args) {

        Mahasiswa mahasiswa1 = new Mahasiswa("Ivan Sawadludyansyah", 89, "Teknik Informatika", "Jl. Tellang","Sistem Informasi");
        

        System.out.println("Nama        : " + mahasiswa1.getNama());
        System.out.println("NIM         : " + mahasiswa1.getNim());
        System.out.println("Jurusan     : " + mahasiswa1.getJurusan());
        System.out.println("Prodi       : " + mahasiswa1.getProdi());
        System.out.println("Alamat      : " + mahasiswa1.getAlamat());
    }
}