/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package profil;



public class Profil {
    String nama;
    int nim;
    String prodi;
    String alamat;
    String ukm;
    static String universitas;
    
    Profil(String name, int NIM, String prodi, String alamat){
        nama = name;
        nim = NIM;
        this.prodi = prodi;
        this.alamat = alamat;  
    }
    
    public void setNama(String nama){
        this.nama = nama;
    }
    
    public String getNama(){
        return nama;
    }

    public void setNim(int NIM){
        nim = NIM;
    }
    
    int getNim(){
        return nim;
    }
    
    public void setProdi(String prodi){
        this.prodi = prodi;
    }
    
    public String getProdi(){
        return prodi;
    }
    
    public void setAlamat(String alamat){
        this.alamat = alamat;
    }
    
    public String getAlamat(){
        return alamat;
    }
    
    public static void setUniversitas(String namaUniversitas){
        universitas = namaUniversitas;
    }
    
    public static String getUniversitas(){
        return universitas;
    }
    
    public void setUkm(String ukm){
        this.ukm = ukm;
    }
    
    public String getUkm(){
        return ukm;
    }
    
    
    
    public static void main(String[] args) {
        Profil.setUniversitas("Universitas Trunojoyo Madura");
        Profil mahasiswa = new Profil("Ivan Sawadludyansyah", 89, 
                "Sistem Informasi", "Jl.Tellang");
        mahasiswa.setUkm("TOFATEK");
        
        
        System.out.println("Nama :"+mahasiswa.getNama());
        System.out.println("Nim :"+mahasiswa.getNim());
        System.out.println("Prodi:"+mahasiswa.getProdi());
        System.out.println("Alamat :"+mahasiswa.getAlamat());
        System.out.println("Universitas :"+Profil.getUniversitas());
        System.out.println("UKM :"+mahasiswa.getUkm());
    }
    
}